package com.example.tictactoe;

import java.util.Scanner;

public class Game {
    private final Board board = new Board();
    private final Scanner scanner = new Scanner(System.in);
    private final Player playerX = new Player("Player X", 'X');
    private final Player playerO = new Player("Player O", 'O');
    private Player currentPlayer;

    public void start() {
        System.out.println("Welcome to Tic-Tac-Toe (Human vs Human) — Maven project!");
        boolean playAgain;
        do {
            board.reset();
            currentPlayer = playerX;
            playSingleGame();
            playAgain = askPlayAgain();
        } while (playAgain);
        System.out.println("Thanks for playing.");
    }

    private void playSingleGame() {
        while (true) {
            board.print();
            int move = askMove();
            board.setCell(move, currentPlayer.getSymbol());
            if (board.isWin(currentPlayer.getSymbol())) {
                board.print();
                System.out.println(currentPlayer.getName() + " wins!");
                break;
            }
            if (board.isFull()) {
                board.print();
                System.out.println("It's a draw!");
                break;
            }
            switchPlayer();
        }
    }

    private int askMove() {
        int pos;
        while (true) {
            try {
                System.out.printf("%s (%s), enter move (1-9): ", currentPlayer.getName(), currentPlayer.getSymbol());
                pos = Integer.parseInt(scanner.nextLine());
                if (pos < 1 || pos > 9) { System.out.println("Choose 1-9."); continue; }
                if (!board.isCellEmpty(pos)) { System.out.println("Taken."); continue; }
                return pos;
            } catch (Exception e) { System.out.println("Invalid."); }
        }
    }

    private boolean askPlayAgain() {
        while (true) {
            System.out.print("Play again? (y/n): ");
            String s = scanner.nextLine().trim().toLowerCase();
            if (s.equals("y")) return true;
            if (s.equals("n")) return false;
        }
    }

    private void switchPlayer() { currentPlayer = (currentPlayer == playerX) ? playerO : playerX; }
}
