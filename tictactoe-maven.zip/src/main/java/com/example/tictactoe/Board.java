package com.example.tictactoe;

public class Board {
    private final char[] cells = new char[10];

    public Board() { reset(); }

    public void reset() { for (int i=1;i<=9;i++) cells[i]=' '; }

    public boolean isCellEmpty(int p){ return cells[p]==' '; }

    public void setCell(int p,char c){ cells[p]=c; }

    public boolean isFull(){ for(int i=1;i<=9;i++) if(cells[i]==' ') return false; return true; }

    public boolean isWin(char p){
        return line(p,1,2,3)||line(p,4,5,6)||line(p,7,8,9)||
               line(p,1,4,7)||line(p,2,5,8)||line(p,3,6,9)||
               line(p,1,5,9)||line(p,3,5,7);
    }

    private boolean line(char p,int a,int b,int c){ return cells[a]==p&&cells[b]==p&&cells[c]==p; }

    public void print(){
        System.out.println();
        System.out.println(" "+cells[1]+" | "+cells[2]+" | "+cells[3]);
        System.out.println("---+---+---");
        System.out.println(" "+cells[4]+" | "+cells[5]+" | "+cells[6]);
        System.out.println("---+---+---");
        System.out.println(" "+cells[7]+" | "+cells[8]+" | "+cells[9]);
        System.out.println();
    }
}
